package uk.ac.aston.oop.uml.media;

import java.util.ArrayList;

public class Database {
    private ArrayList<Item> items;

    public Database() {
        items = new ArrayList<>();
    }

    public void addItem(Item item) {
        items.add(item);
    }

    public void print() {
        for (Item item : items) {
            System.out.println(item);
        }
    }

    public static void main(String[] args) {
        Database db = new Database();
        db.addItem(new Video("Some Movie", "Some Director", 120));
        db.addItem(new CD("Some Album", "Some Artist", 10, 40));
        db.print();
    }
}
