package uk.ac.aston.oop.dpatterns.fmethod;

public interface Command extends Runnable {
   
}
