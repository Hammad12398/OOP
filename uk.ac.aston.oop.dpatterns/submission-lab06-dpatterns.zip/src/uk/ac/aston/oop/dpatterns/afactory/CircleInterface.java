package uk.ac.aston.oop.dpatterns.afactory;

public interface CircleInterface {
  
    void setFill(int red, int green, int blue);
    void setPosition(int x, int y);
    void setRadius(int radius);

