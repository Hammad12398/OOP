package uk.ac.aston.oop.jcf.generics;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class BestOf<T extends Comparable<? super T>> {
    private List<T> items;
    private int maxItems;

    public BestOf(int maxItems) {
        if (maxItems <= 0) {
            throw new IllegalArgumentException("maxItems must be positive.");
        }
        this.items = new ArrayList<>();
        this.maxItems = maxItems;
    }

    public List<T> getItems() {
        return Collections.unmodifiableList(items);
    }

    public void add(T c) {
        items.add(c);
        Collections.sort(items);
        if (items.size() > maxItems) {
            items.remove(0);  // Remove the smallest item
        }
    }

    public static void main(String[] args) {
        BestOf<Integer> bestScores = new BestOf<>(3);
        bestScores.add(3000);
        bestScores.add(4200);
        bestScores.add(2600);
        bestScores.add(1500);

        for (Integer score : bestScores.getItems()) {
            System.out.println(score);  // Expected to print 2600, 3000, 4200
        }
    }
}
