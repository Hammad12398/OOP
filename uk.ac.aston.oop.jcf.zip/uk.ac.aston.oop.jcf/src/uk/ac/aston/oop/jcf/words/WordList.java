package uk.ac.aston.oop.jcf.words;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

/**
 * Reads the words from a Hunspell word list file.
 * Ignores suffixes, and organizes by first letter.
 */
public class WordList {

    private Map<Character, Set<String>> wordsByLetter;

    public WordList(InputStream is) throws IOException {
        wordsByLetter = new HashMap<>();
        try (Scanner sc = new Scanner(is)) {
            readWords(sc);
        }
    }

    private void readWords(Scanner sc) {
        
        if (sc.hasNextLine()) { 
            sc.nextLine();
        }

        while (sc.hasNextLine()) {
            String line = sc.nextLine();
            String[] parts = line.split("/");
            String word = parts[0];
            char firstChar = word.charAt(0);

            wordsByLetter.computeIfAbsent(firstChar, k -> new HashSet<>()).add(word);
        }
    }

    public Set<String> searchWords(char firstLetter, String substring) {
        Set<String> results = new HashSet<>();
        Set<String> wordsStartingWithLetter = wordsByLetter.get(firstLetter);

        if (wordsStartingWithLetter != null) {
            for (String w : wordsStartingWithLetter) {
                if (w.contains(substring)) {
                    results.add(w);
                }
            }
        }
        return results;
    }

}
