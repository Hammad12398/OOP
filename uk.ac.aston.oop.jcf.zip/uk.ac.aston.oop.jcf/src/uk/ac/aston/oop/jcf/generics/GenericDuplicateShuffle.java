package uk.ac.aston.oop.jcf.generics;

import java.util.ArrayList;  // Import ArrayList
import java.util.Collections;
import java.util.List;
import java.util.Random;

public class GenericDuplicateShuffle {

    public static <T> void shuffle(List<T> items, Random rnd) {
        for (int i = items.size() - 1; i > 0; i--) {
            int index = rnd.nextInt(i + 1);
            T temp = items.get(index);
            items.set(index, items.get(i));
            items.set(i, temp);
        }
    }

    public static <T> void duplicate(T elem, int n, List<? super T> items) {
        for (int i = 0; i < n; i++) {
            items.add(elem);
        }
    }

    public static void main(String[] args) {
        Random rnd = new Random();

        List<Object> listObjects = new ArrayList<>();
        duplicate("A", 2, listObjects);
        duplicate("B", 3, listObjects);
        duplicate("C", 1, listObjects);
        shuffle(listObjects, rnd);
        System.out.println("Shuffled List<Object>: " + listObjects);

        List<Number> listNumbers = new ArrayList<>();
        duplicate(1.0f, 3, listNumbers);
        duplicate(1.5f, 2, listNumbers);
        duplicate(2, 1, listNumbers);
        shuffle(listNumbers, rnd);
        System.out.println("Shuffled List<Number>: " + listNumbers);
    }
}
