package uk.ac.aston.oop.jcf.todo;

import java.util.InputMismatchException;
import java.util.Random;
import java.util.Scanner;

/**
 * Text-based application to keep a to-do list.
 */
public class ToDoMain {

    private final ToDoList todo = new ToDoList();
    private final Random rnd = new Random();
    private final Scanner sc = new Scanner(System.in);

    public void run() {
        boolean done = false;
        while (!done) {
            printList();
            MenuOption option = pickOption();
            try {
                done = option.getCommand().call();
            } catch (Exception e) {
                System.err.println("An error occurred while executing the command: " + e.getMessage());
                e.printStackTrace();
            }
        }
    }

    private void printList() {
        int i = 1;
        if (todo.isEmpty()) {
            System.out.println("\nNo tasks in your TODO list\n");
        } else {
            System.out.println("\nYour TODO list:");
            for (ToDoItem item : todo) {
                System.out.println(String.format("%d. %s (%s)", i++, item.getDescription(), item.isDone() ? "done" : "to do"));
            }
            System.out.println();
        }
    }

    private MenuOption pickOption() {
        MenuOption[] options = getOptions();
        System.out.println("Available options:");
        for (int i = 0; i < options.length; i++) {
            System.out.println(String.format("%d. %s", i + 1, options[i].getDescription()));
        }

        int selected = promptInteger("Enter an option number", 1, options.length);
        return options[selected - 1];
    }

    private MenuOption[] getOptions() {
        return new MenuOption[]{
            new MenuOption("Add item", this::addItem),
            new MenuOption("Mark as done", this::markDone),
            new MenuOption("Remove item by position", this::removeByPosition),
            new MenuOption("Remove by text", this::removeByText),
            new MenuOption("Remove all done items", this::removeDone),
            new MenuOption("Move to the top", this::moveToTop),
            new MenuOption("Shuffle", this::shuffle),
            new MenuOption("Quit", this::quit),
        };
    }

    // Other private methods remain unchanged

    public static void main(String[] args) {
        new ToDoMain().run();
    }
}

