package uk.ac.aston.oop.jcf.generics;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

class GenericDuplicateShuffleTest {

    @Test
    void testDuplicate() {
        // Initialize the list with some integers.
        List<Integer> list = new ArrayList<>();
        list.add(1);
        list.add(23);

        // Call the duplicate method to add the integer 42 three times.
        GenericDuplicateShuffle.duplicate(42, 3, list);

        // Assert the size of the list and the number of occurrences of 42.
        assertEquals(5, list.size(), "List should have 5 elements after duplication.");
        assertTrue(list.contains(42), "List should contain the duplicated element 42.");
        assertEquals(3, list.stream().filter(i -> i == 42).count(), "Element 42 should appear 3 times in the list.");
    }

    @Test
    void testShuffle() {
        // Initialize the list with some integers.
        List<Integer> list = new ArrayList<>();
        list.add(1);
        list.add(2);
        list.add(3);

        // Create a Random instance with a fixed seed to ensure reproducibility.
        Random rnd = new Random(0);

        // Call the shuffle method.
        GenericDuplicateShuffle.shuffle(list, rnd);

        // Assert that the list is shuffled but still contains the same elements.
        assertEquals(3, list.size(), "List size should remain constant after shuffling.");
        assertTrue(list.contains(1) && list.contains(2) && list.contains(3), "List should contain the same elements after shuffling.");
    }
}
