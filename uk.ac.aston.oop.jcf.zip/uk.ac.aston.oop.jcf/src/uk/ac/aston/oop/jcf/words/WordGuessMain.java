package uk.ac.aston.oop.jcf.words;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

public class WordGuessMain {
    private static final String DICT_RESOURCE_PATH = "/en_GB-ise.dic";
    private final WordList wordList;
    private final Scanner sc;
    private char firstLetter;
    private Set<String> candidates;

    public WordGuessMain(WordList wl, Scanner sc) {
        this.wordList = wl;
        this.sc = sc;
    }

    public void run() {
        buildCandidateSet();
        askUserToGuess();
    }

    protected void buildCandidateSet() {
        firstLetter = promptCharacter("Enter the first letter: ");
        String initialSearch = promptString("Enter an initial search: ");
        candidates = wordList.searchWords(firstLetter, initialSearch);

        boolean done = false;
        while (!done) {
            System.out.println(candidates.size() + " candidates currently selected");
            String pattern = promptString(
                "Enter a command (+WORD, -WORD, *WORD) or enter an empty line to switch to guessing\n>");
            done = processLine(pattern);
        }
    }

    protected void askUserToGuess() {
        if (candidates.isEmpty()) {
            System.out.println("No candidates left.");
        } else {
            while (!candidates.isEmpty()) {
                String guess = promptString("Make a guess: ");
                if (candidates.contains(guess)) {
                    System.out.println("Correct");
                    break; // Exit the loop if the user guessed correctly.
                } else {
                    System.out.println("Incorrect");
                    System.out.println("Valid candidates were: " + candidates);
                    break; // Modify according to your game's logic.
                }
            }
        }
    }

    protected boolean processLine(String pattern) {
        if (pattern.isEmpty()) {
            return true; // The buildup of the candidates is done.
        }

        char cmd = pattern.charAt(0);
        String substring = pattern.substring(1);

        Set<String> results;
        switch (cmd) {
            case '+':
                results = wordList.searchWords(firstLetter, substring);
                candidates.addAll(results);
                break;
            case '-':
                results = wordList.searchWords(firstLetter, substring);
                candidates.removeAll(results);
                break;
            case '*':
                results = wordList.searchWords(firstLetter, substring);
                candidates.retainAll(results);
                break;
            default:
                System.out.println("Command '" + cmd + "' not recognized.");
                break;
        }
        return false; // We are not done building up the set of candidates.
    }

    private char promptCharacter(String question) {
        System.out.print(question);
        char c = sc.findInLine(".").charAt(0);
        sc.nextLine(); // Clear the buffer.
        return c;
    }

    private String promptString(String question) {
        System.out.print(question);
        return sc.nextLine().strip();
    }

    public static void main(String[] args) {
        try (Scanner sc = new Scanner(System.in);
             InputStream dictStream = WordGuessMain.class.getResourceAsStream(DICT_RESOURCE_PATH)) {
            if (dictStream == null) {
                throw new IOException("Dictionary file not found at " + DICT_RESOURCE_PATH);
            }
            final WordList wl = new WordList(dictStream);
            new WordGuessMain(wl, sc).run();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
