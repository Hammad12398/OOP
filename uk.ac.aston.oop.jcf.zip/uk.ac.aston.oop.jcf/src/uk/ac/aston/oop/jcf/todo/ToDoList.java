package uk.ac.aston.oop.jcf.todo;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

/**
 * To-do list, implemented through a JCF List.
 * This class allows manipulation of a list of ToDoItem objects,
 * including shuffling the list items in a random order.
 */
public class ToDoList implements Iterable<ToDoItem> {

    protected final List<ToDoItem> items = new ArrayList<>();

    @Override
    public Iterator<ToDoItem> iterator() {
        return items.iterator();
    }

    public boolean isEmpty() {
        return items.isEmpty();
    }

    public void add(ToDoItem toDoItem) {
        items.add(toDoItem);
    }

    public int size() {
        return items.size();
    }

    public void markDone(int i) {
        if (i >= 0 && i < items.size()) {
            items.get(i).setDone(true);
        }
    }

    public void remove(int i) {
        if (i >= 0 && i < items.size()) {
            items.remove(i);
        }
    }

    public void removeAllContaining(String substring) {
        items.removeIf(item -> item.getDescription().contains(substring));
    }

    public void removeAllDone() {
        items.removeIf(ToDoItem::isDone);
    }

    public void moveToTop(int i) {
        if (i >= 0 && i < items.size()) {
            ToDoItem item = items.remove(i);
            items.add(0, item);
        }
    }

    /**
     * Shuffles the items in the list using the provided Random instance.
     * This method uses the Fisher-Yates shuffle algorithm.
     *
     * @param rnd the random number generator used to shuffle.
     */
    public void shuffle(Random rnd) {
        if (rnd == null) {
            throw new IllegalArgumentException("Random object must not be null");
        }

        for (int i = items.size() - 1; i > 0; i--) {
            int index = rnd.nextInt(i + 1);
            ToDoItem temp = items.get(index);
            items.set(index, items.get(i));
            items.set(i, temp);
        }
    }
}
