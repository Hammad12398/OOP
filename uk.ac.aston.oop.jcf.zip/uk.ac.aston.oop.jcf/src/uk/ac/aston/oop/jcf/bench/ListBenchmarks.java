package uk.ac.aston.oop.jcf.bench;

import org.openjdk.jmh.annotations.Benchmark;
import org.openjdk.jmh.runner.Runner;
import org.openjdk.jmh.runner.RunnerException;
import org.openjdk.jmh.runner.options.Options;
import org.openjdk.jmh.runner.options.OptionsBuilder;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class ListBenchmarks {

    protected static final int ELEMENTS = 100;

    protected void addToEnd(List<Integer> l, int n) {
        for (int i = 0; i < n; i++) {
            l.add(i);
        }
    }

    protected void addToBeginning(List<Integer> l, int n) {
        for (int i = 0; i < n; i++) {
            l.add(0, i);
        }
    }

    @Benchmark
    public void addToEndArrayList() {
        List<Integer> list = new ArrayList<>();
        addToEnd(list, ELEMENTS);
    }

    @Benchmark
    public void addToEndLinkedList() {
        List<Integer> list = new LinkedList<>();
        addToEnd(list, ELEMENTS);
    }

    @Benchmark
    public void addToBeginningArrayList() {
        List<Integer> list = new ArrayList<>();
        addToBeginning(list, ELEMENTS);
    }

    @Benchmark
    public void addToBeginningLinkedList() {
        List<Integer> list = new LinkedList<>();
        addToBeginning(list, ELEMENTS);
    }

    public static void main(String[] args) throws RunnerException {
        Options options = new OptionsBuilder().include(
                ListBenchmarks.class.getSimpleName()
        ).forks(1).build();
        new Runner(options).run();
    }
}
